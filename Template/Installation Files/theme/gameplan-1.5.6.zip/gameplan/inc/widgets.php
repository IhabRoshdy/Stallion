<?php
/* Include custom widgets file here
 *
 * Should be placed in \inc\widgets\ folder
 */
include('widgets/latest-post-type.php');
?>