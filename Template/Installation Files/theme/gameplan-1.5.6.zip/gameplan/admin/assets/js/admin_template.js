// JavaScript Document
(function($){	
	
})(jQuery);